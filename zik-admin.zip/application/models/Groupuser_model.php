<?php
Class GroupUser_model extends MY_Model
{
    var $table = 'groupuser';


}