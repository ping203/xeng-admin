<?php
$lang['home_info']							= 'Trang quản lý hệ thống';

$lang['notice_stats']						= 'Thống kê';
$lang['notice_stats_user']					= 'Thành viên';
$lang['notice_stats_user_total']			= 'Tổng số thành viên';
$lang['notice_stats_user_verify_wait']		= 'Thành viên chờ xác thực';
$lang['notice_stats_user_verify_yes']		= 'Thành viên đã xác thực';
$lang['notice_stats_amount']				= 'Doanh số';
$lang['notice_stats_amount_total']			= 'Tổng doanh số';
$lang['notice_stats_amount_0']				= 'Doanh số hôm nay';
$lang['notice_stats_amount_1']				= 'Doanh số hôm qua';

$lang['button_backup']						= 'Backup Data';
$lang['notice_backup_success']				= 'Cơ sở dữ liệu đã được backup!';

?>