<?php
$lang['contact_info']							= 'Quản lý liên hệ';