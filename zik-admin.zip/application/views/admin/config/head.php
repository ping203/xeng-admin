<div class="titleArea">
	<div class="wrapper">
		<div class="pageTitle">
			<h5>Quản lý config</h5>
		</div>
		<div class="horControlB menu_action">
			<ul>
				
			</ul>
		</div>
		<div class="clear"></div>
	</div>
</div>