<div class="titleArea">
    <div class="wrapper">
        <div class="pageTitle">
            <h5>Quản lý marketing</h5>
        </div>
        <div class="horControlB menu_action">
            <ul>
			 <li><a href="<?php echo admin_url('marketing/addsourcegiftcode') ?>">
                        <img src="<?php echo public_url('admin') ?>/images/icons/control/16/add.png">
                        <span>Thêm nguồn giftcode</span>
                    </a></li>
                <li><a href="<?php echo admin_url('marketing/addcampain') ?>">
                        <img src="<?php echo public_url('admin') ?>/images/icons/control/16/add.png">
                        <span>Thêm campaign</span>
                    </a></li>
                <li><a href="<?php echo admin_url('marketing/addmedium') ?>">
                        <img src="<?php echo public_url('admin') ?>/images/icons/control/16/add.png">
                        <span>Thêm medium</span>
                    </a></li>
                <li><a href="<?php echo admin_url('marketing/addsource') ?>">
                        <img src="<?php echo public_url('admin') ?>/images/icons/control/16/add.png">
                        <span>Thêm source</span>
                    </a></li>
                <li><a href="<?php echo admin_url('marketing/add') ?>">
                        <img src="<?php echo public_url('admin') ?>/images/icons/control/16/add.png">
                        <span>Thêm mới</span>
                    </a></li>
                <li><a href="<?php echo admin_url('marketing/index') ?>">
                        <img src="<?php echo public_url('admin') ?>/images/icons/control/16/list.png">
                        <span>Danh sách</span>
                    </a></li>
            </ul>
        </div>
        <div class="clear"></div>
    </div>
</div>