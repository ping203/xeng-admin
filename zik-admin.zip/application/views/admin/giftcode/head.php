<div class="titleArea">
    <div class="wrapper">
        <div class="pageTitle">
            <h5>Giftcode</h5>
        </div>
        <div class="horControlB menu_action">
        </div>
        <div class="clear"></div>
    </div>
</div>